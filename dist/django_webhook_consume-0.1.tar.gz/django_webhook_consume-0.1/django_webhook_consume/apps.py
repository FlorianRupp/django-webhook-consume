from django.apps import AppConfig


class WebhookConsumeConfig(AppConfig):
    name = 'django_webhook_consume'
