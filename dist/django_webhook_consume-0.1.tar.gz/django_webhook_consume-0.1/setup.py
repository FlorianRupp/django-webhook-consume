from setuptools import setup

setup(packages=["django_webhook_consume"],
      install_requires=['django'])